fetch('http://localhost:3000/data')
  .then(res => res.json())
  .then(data => {
    const report = document.getElementById('report');
    report.innerHTML = Object.entries(data).map(
      ([site, time]) => `<p>${site}: ${Math.round(time/60)} mins</p>`
    ).join('');
  });