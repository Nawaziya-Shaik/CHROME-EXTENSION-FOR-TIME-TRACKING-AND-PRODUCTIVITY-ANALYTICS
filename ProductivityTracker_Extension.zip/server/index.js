const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json());

app.post('/save', (req, res) => {
  const data = req.body;
  fs.writeFileSync('db.json', JSON.stringify(data, null, 2));
  res.send({ message: 'Saved!' });
});

app.get('/data', (req, res) => {
  const raw = fs.readFileSync('db.json');
  res.send(JSON.parse(raw));
});

app.listen(3000, () => console.log("Server on http://localhost:3000"));